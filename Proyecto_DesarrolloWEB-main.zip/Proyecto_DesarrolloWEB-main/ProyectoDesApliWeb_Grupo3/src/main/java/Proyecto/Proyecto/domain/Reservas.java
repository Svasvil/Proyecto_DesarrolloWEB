package Proyecto.Proyecto.domain;

public class Reservas {

}
