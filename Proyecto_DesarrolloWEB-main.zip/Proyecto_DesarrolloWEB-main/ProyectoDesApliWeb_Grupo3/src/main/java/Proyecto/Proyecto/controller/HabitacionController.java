package Proyecto.Proyecto.controller;

public class HabitacionController {

}
