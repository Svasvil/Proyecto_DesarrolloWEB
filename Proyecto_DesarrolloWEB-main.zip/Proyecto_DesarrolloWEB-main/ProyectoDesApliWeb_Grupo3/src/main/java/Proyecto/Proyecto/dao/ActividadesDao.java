package Proyecto.Proyecto.dao;

public interface ActividadesDao {

}
