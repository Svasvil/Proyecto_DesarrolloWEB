package Proyecto.Proyecto.domain;

public class Habitacion {

}
