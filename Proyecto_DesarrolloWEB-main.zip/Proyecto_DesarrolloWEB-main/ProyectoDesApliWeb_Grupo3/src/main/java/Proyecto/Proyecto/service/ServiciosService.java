package Proyecto.Proyecto.service;

public interface ServiciosService {

}
