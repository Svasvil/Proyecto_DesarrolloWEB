package Proyecto.Proyecto;

public class ProjectConfig {

}
