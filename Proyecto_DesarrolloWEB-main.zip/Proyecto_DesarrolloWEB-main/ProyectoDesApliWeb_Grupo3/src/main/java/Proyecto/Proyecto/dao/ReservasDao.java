package Proyecto.Proyecto.dao;

public interface ReservasDao {

}
