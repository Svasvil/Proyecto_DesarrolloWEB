package Proyecto.Proyecto.service;

public interface ActividadesService {

}
