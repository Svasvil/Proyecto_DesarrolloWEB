package Proyecto.Proyecto.controller;

public class ActividadesController {

}
